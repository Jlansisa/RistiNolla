package application.my.bluetoothristinolla2;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by jarno on 5.2.2017.
 */

public class ConnectedThread extends Thread{

    /*
     * Data members
     */

    // Bluetooth socket and stream to use
    private final BluetoothSocket mmSocket;
    private final OutputStream mmOutStream;

    // Value to send (square number)
    int sendValue;

    //info
    public TextView info;

    //MainActivity
    Activity mActivity;

    // Result check
    CharHandler winnerCheckLocal;


    /*
     * Construct
     */

    ConnectedThread(
            BluetoothSocket socket,
            TextView infotext,
            int sV,
            Activity activity,
            CharHandler wCheckL ){

        // Set datamembers by given parameters
        mmSocket = socket;
        info = infotext;
        sendValue = sV;
        mActivity = activity;

        // Helper object for checking if sendValue is winning
        winnerCheckLocal = wCheckL;

        //temporary stream variable
        OutputStream tmpOut = null;

        // Get the output streams, using temp objects because
        // member streams are final
        try {
            tmpOut = mmSocket.getOutputStream();
        } catch (IOException e) { }

        //assign temp streams as final
        mmOutStream = tmpOut;
    }


    /*
     * Thread start
     */

    public void run(){

        // Keep listening to the InputStream until an exception occurs
        try {

            //Write to the outt stream the given value

            // 9 = device connection and game start signal
            if(sendValue == 9){

                // Get locat bluetooth MAC
                // and pass it on the remote device
                String mac = BluetoothAdapter.getDefaultAdapter().getAddress();
                byte[] macBuffer = new byte[1024];
                macBuffer=mac.getBytes();
                mmOutStream.write(macBuffer, 0, macBuffer.length);
            }
            // otherwise pass the sendValues on the remote device
            else {
                mmOutStream.write(sendValue);
            }

            // Update the UI
            info.post(new Update());

            // Close stream and socket
            mmOutStream.close();
            mmSocket.close();

        } catch (IOException e) {
            //error handling;
        }
    }

    /*
     *  Subclass (thread) for communicating with UI
     */
    class Update implements Runnable {

        public void run() {

            // 9 = game start
            // Update the infotext
            if(sendValue == 9){
                info.setText("Game start");
                info.invalidate();
            } else {

                // Initialize first button
                Button btn = (Button)mActivity.findViewById(R.id.B0);

                // Win trigger. if true, you won
                boolean winTrigger = false;

                // Check result for each possible square (0-8)
                switch(sendValue){
                    case 0:
                        btn = (Button)mActivity.findViewById(R.id.B0);
                        winTrigger = winnerCheckLocal.calculateFields("ULC");
                        break;
                    case 1:
                        btn = (Button)mActivity.findViewById(R.id.B1);
                        winTrigger = winnerCheckLocal.calculateFields("UM");
                        break;
                    case 2:
                        btn = (Button)mActivity.findViewById(R.id.B2);
                        winTrigger = winnerCheckLocal.calculateFields("URC");
                        break;
                    case 3:
                        btn = (Button)mActivity.findViewById(R.id.B3);
                        winTrigger = winnerCheckLocal.calculateFields("MLC");
                        break;
                    case 4:
                        btn = (Button)mActivity.findViewById(R.id.B4);
                        winTrigger = winnerCheckLocal.calculateFields("MM");
                        break;
                    case 5:
                        btn = (Button)mActivity.findViewById(R.id.B5);
                        winTrigger = winnerCheckLocal.calculateFields("MRC");
                        break;
                    case 6:
                        btn = (Button)mActivity.findViewById(R.id.B6);
                        winTrigger = winnerCheckLocal.calculateFields("DLC");
                        break;
                    case 7:
                        btn = (Button)mActivity.findViewById(R.id.B7);
                        winTrigger = winnerCheckLocal.calculateFields("DM");
                        break;
                    case 8:
                        btn = (Button)mActivity.findViewById(R.id.B8);
                        winTrigger = winnerCheckLocal.calculateFields("DRC");
                        break;
                }
                // Mark my buttons as X
                btn.setText("X");

                // Disable button to avoid more clicks
                btn.setEnabled(false);

                // Check if you win
                if(winTrigger == true){
                    info.setText(R.string.you_win);
                    info.postInvalidate();
                }
            }
        }
    }
}
