

/**
 * Created by jarno on 5.2.2017.
 */
package application.my.bluetoothristinolla2;

import android.bluetooth.BluetoothDevice;
import android.app.Activity;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;


public class ConnectThread extends Thread  {

    /*
     * Data members
     */

    //UI related
    private Activity mActivity;
    private TextView info ;

    //Bluetooth related
    private final BluetoothSocket mmSocket;
    private final BluetoothDevice mmDevice;

    // value to send
    int  sendValue;

    // Winner check
    CharHandler winnerCheckLocal;


    /*
     * Construct
     */
    public ConnectThread(
            BluetoothDevice device,
            Activity activity,
            TextView infotext,
            int sV,
            CharHandler wcheckL){

        // Set UI
        info = infotext;
        mActivity = activity;

        // valuet to send and winner check
        sendValue = sV;
        winnerCheckLocal = wcheckL;

        // Set device and create a socket
        mmDevice = device;

        //temporary socket to assign as a final mmSocket
        BluetoothSocket tmp = null;

        // Get a BluetoothSocket to connect with the given BluetoothDevice
        try {
            // MY_UUID is the app's UUID string, also used by the server code
            tmp = device.createRfcommSocketToServiceRecord(ThreadServer.MY_SERVICE_UUID);
        } catch (IOException e) { Log.d("TAGI", e.toString());}

        // set final socket
        mmSocket = tmp;

    }

    /*
     * Start
     */

    public void run() {

        // create a connection
        try {
            // Connect the device through the socket. This will block
            // until it succeeds or throws an exception
            mmSocket.connect();
        } catch (IOException connectException) {
            // Unable to connect; close the socket and get out
            try {
                mmSocket.close();
            } catch (IOException closeException) {
            }
            return;
        }

        // Do work to manage the connection (in a separate thread)
        new ConnectedThread(mmSocket, info, sendValue, mActivity, winnerCheckLocal).start();
    }
}
