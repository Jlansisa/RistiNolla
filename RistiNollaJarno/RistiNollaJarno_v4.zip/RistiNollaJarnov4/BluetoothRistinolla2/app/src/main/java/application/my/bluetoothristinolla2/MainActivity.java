package application.my.bluetoothristinolla2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.widget.ArrayAdapter;

import java.util.List;

public class MainActivity extends AppCompatActivity
{
    /*
     * Data members
     */

    // Game buttons
    Button b0, b1, b2, b3, b4, b5, b6, b7, b8;


    // Info textfield
    private TextView info ;

    // Bluetooth related buttons
    private Button btnFind;
    private Button btnWait;
    private Button btnQuit;

    // Game result checking objects
    public CharHandler winnerCheckLocal;
    public CharHandler winnerCheckRemote;

    // Game layout (GridView)
    View grid;

    //Bluetooth device list
    ListView list;

    //Bluetooth connection object
    Connection BT;

    // intent to restart the activity
    Intent starterIntent;

    /*
     * Construct
     */

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        starterIntent = getIntent();

        winnerCheckLocal = new CharHandler();
        winnerCheckRemote = new CharHandler();

        // Activate Bluetooth
        BT = new Connection(this, winnerCheckLocal, winnerCheckRemote);

        // Bluetooth controls:

        // Button to find an opponent
        btnFind = (Button)findViewById(R.id.find);

        //Button to set discoverable and wait for an opponent
        btnWait = (Button)findViewById(R.id.wait);

        //Button to quit the game
        btnQuit = (Button)findViewById(R.id.btnQuit);

        // Bluetooth device list
        list = (ListView)findViewById(R.id.listView1);

        // General infotext
        info = (TextView)findViewById(R.id.infotext);

        //Game controls

        // 9 buttons
        b0 = (Button)findViewById(R.id.B0);
        b1 = (Button)findViewById(R.id.B1);
        b2 = (Button)findViewById(R.id.B2);
        b3 = (Button)findViewById(R.id.B3);
        b4 = (Button)findViewById(R.id.B4);
        b5 = (Button)findViewById(R.id.B5);
        b6 = (Button)findViewById(R.id.B6);
        b7 = (Button)findViewById(R.id.B7);
        b8 = (Button)findViewById(R.id.B8);

        // idview
        grid = (View)findViewById(R.id.game_layout_grid);

        //start
        begin();
    }

    /*
     * Beginning
     */

    protected void begin(){

        /*
         * Event listeners
         */

        // Start to discover opponent devices
        btnFind.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                findOpponent();
            }
        });

        // Set my device visible to receive game request
        btnWait.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                waitOpponent();

            }
        });

        // Gmae End
        btnQuit.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                quit();

            }
        });

        // Use this to handle diffrent states of the game
        info.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                // info text for triggering Game Over
                String win = getApplicationContext().getString(R.string.you_win);
                String lose = getApplicationContext().getString(R.string.you_lose);

                // if game started, hide device list and set button grid visible
                if(s.toString().equals("Game start")) {
                    list.setVisibility(View.GONE);
                    btnWait.setVisibility(View.GONE);
                    btnFind.setVisibility(View.GONE);
                    grid.setVisibility(View.VISIBLE);
                    btnQuit.setVisibility(View.VISIBLE);

                    // Listeners for each button
                    b0.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(0);Log.d("TAGI","Button 0 clicked");}});
                    b1.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(1);Log.d("TAGI","Button 1 clicked");}});
                    b2.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(2);Log.d("TAGI","Button 2 clicked");}});
                    b3.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(3);Log.d("TAGI","Button 3 clicked");}});
                    b4.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(4);Log.d("TAGI","Button 4 clicked");}});
                    b5.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(5);Log.d("TAGI","Button 5 clicked");}});
                    b6.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(6);Log.d("TAGI","Button 6 clicked");}});
                    b7.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(7);Log.d("TAGI","Button 7 clicked");}});
                    b8.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {sendTurn(8);Log.d("TAGI","Button 8 clicked");}});
                } else if(
                        s.toString().equals(win) || s.toString().equals(lose)) {
                    // If winning line is found, disable all buttons on the grid
                    // Game Over
                    disableGrid();
                }

            }
        });
    }

    /*
     * Private methods
     */

    /*
     *  Start discovery to find BT devices
     *  and list them on ListView
     */
    private void findOpponent(){

        if(BT.enableDiscovery()){

            // Disable find button to avoid more clicks
            disableButton(btnFind, R.string.bt_finding);

            // Activate visibility button to change the mode (client -> server)
            enableButton(btnWait, (R.string.Wait));
        } else {
            info.setText(R.string.bt_error);
        }
    }

    /*
     *  Start visibility to receive
     *  game requests
     */
    private void waitOpponent(){

        if(BT.enableVisibility()){

            // Disable wait button to avoid more clicks
            disableButton(btnWait, R.string.bt_waiting);

            // Activate discovery button to change the mode (server -> client)
            enableButton(btnFind, (R.string.Find));
        } else {
            info.setText(R.string.bt_error);
        }
    }

    /*
     *  Disable button and set text
     */
    private void disableButton (Button b, int text){
        b.setEnabled(false);
        b.setText(text);
    }

    /*
     *  Enable button and set text
     */
    private void enableButton (Button b, int text){
        b.setEnabled(true);
        b.setText(text);
    }


    /*
     * Send turn to bluetooth
     */

    private void sendTurn(int sq){

        // Send my turn
        BT.sendTurn(sq);

        // If no winner announced, receive the opponent's turn
        if(info.getText().toString() != "Voitit!") {

            // Receive opponent's turn
            BT.receiveTurn();
        }
    }

    /*
     * disable all buttons on the grid
     */

    private void disableGrid(){
        int[] BUTTON_IDS = {
                R.id.B0, R.id.B1, R.id.B2, R.id.B3, R.id.B4,
                R.id.B5, R.id.B6, R.id.B7, R.id.B8
        };
        for(int id : BUTTON_IDS) {
            Button button = (Button)findViewById(id);
            button.setEnabled(false);
        }
    }

    /*
     * Quit the game and return to the device select
     */

    private void quit(){
        BT.disableDiscovery();
        BT.disableVisibility();
        BT = null;

        Intent intent = new Intent(MainActivity.this,MainActivity.class);

        startActivity(intent);


       this.finish();
    }
}
