/**
 * Created by jarno on 5.2.2017.
 */
package application.my.bluetoothristinolla2;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothAdapter;
import java.io.IOException;
import android.bluetooth.BluetoothSocket;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

public class ThreadServer extends Thread
{
    /*
     * Data members
     */

    // Name for the SDP record when creating server socket
    public static final String MY_SERVICE_NAME = "RistinollaReceiver";

    //Self made unique ID
    public static final UUID MY_SERVICE_UUID =
            UUID.fromString("bb96d1d2-beac-20cd-9b28-1711311b8b55");

    //Socet for incoming connections
    private final BluetoothServerSocket mmServerSocket;

    //BT adapter
    private BluetoothAdapter mBluetoothAdapter;

    //Trigger to control socket status
    private boolean isRunning;

    //main activity imported from super class
    private AppCompatActivity mActivity;

    //info
    private TextView info;

    int sendValue;

    // winner check for remote player
    CharHandler winnerCheckRemote;
    CharHandler winnerCheckLocal;



    /*
     * Construct
     */
    public ThreadServer(
            BluetoothAdapter baa,
            AppCompatActivity activity,
            TextView infotext,
            int sV,
            CharHandler wCheckR,
            CharHandler wCheckL){

        // Set data memebers

        mActivity = activity;
        info = infotext;
        sendValue = sV;
        winnerCheckRemote = wCheckR;
        winnerCheckLocal = wCheckL;

        // Trying to  create sever socket
        BluetoothServerSocket tmp = null;
        try {
            // Set BT adapter
            mBluetoothAdapter=baa;
            tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord(MY_SERVICE_NAME, MY_SERVICE_UUID);

        } catch (IOException e) {
            e.printStackTrace();
        }
        // Set socket
        mmServerSocket = tmp;
    }

    /*
     * Start
     */
    public void run() {
        Log.d("TAGI", "thread server");
        // Initialize socket
        BluetoothSocket socket = null;

        // Num of sockets
        int num=1;

        // Set status
        isRunning = true;

        // Keep listening until exception occurs or a socket is returned
        while (isRunning) {

            // If socket accept fails, break the loop
            try {
                socket = mmServerSocket.accept();
            } catch (IOException e) {
                break;
            }

            // If a connection was accepted, try to start thread
            if (socket != null) {
                try {
                    // Initialize io streams
                    InputStream in = socket.getInputStream();

                    // Create client handler for io messages
                    ClientHandler handler = new ClientHandler(in, num, info, mActivity, sendValue, winnerCheckRemote, winnerCheckLocal);

                    // Create new thread
                    Thread clientThread = new Thread(handler);

                    // Start
                    clientThread.start();

                    // increase counter
                    num++;
                }
             // If thread fails, close the socket
             catch (Exception exc) {
                try
                {
                    socket.close();
                }
                catch (Exception ignore) {}
            }
            }else {
                Log.d("TAGI","Socket doesn't exist");
            }
        }

    }

    public void cancel() {
        try {
            mmServerSocket.close();
        } catch (IOException e) { }
    }
    public void stopTh(){
        isRunning=false;
    }
    public void startTh(){
        isRunning=true;
    }
}
