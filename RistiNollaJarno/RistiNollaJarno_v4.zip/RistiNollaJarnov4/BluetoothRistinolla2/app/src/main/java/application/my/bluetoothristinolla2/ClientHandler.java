package application.my.bluetoothristinolla2;

import android.bluetooth.BluetoothSocket;
import java.io.InputStream;
import java.io.OutputStream;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by jarno on 5.2.2017.
 */

public class ClientHandler implements Runnable
{
    /*
     * Data members
     */

    //Bluetooth socket
    protected BluetoothSocket clientSocket;

    //trigger
    private boolean running;

    //socket number
    private int number;

    //info
    private TextView info;

    // Char, read from incoming stream
    char merkki;

    // Value, int cast merkki
    int receivedValue,

    // Send value of outgoing stream
    sendValue;

    //UI
    AppCompatActivity mActivity;
    Button btn;

    // Streams
    InputStream in;

    // Remote device MAC
    String Remote_mac;

    // Winner check for remote player
    CharHandler winnerCheckRemote;
    CharHandler winnerCheckLocal;

    /*
     * Construct
     */
    public ClientHandler(
            InputStream stream_in,
            int num,
            TextView infotext,
            AppCompatActivity Activity,
            int sV,
            CharHandler vCheckR,
            CharHandler vCheckL){
        /*
         * Data members
         */

        //UI
        info = infotext;
        mActivity = Activity;

        //socket number
        number=num;

        // value to send out
        sendValue = sV;

        // streams
        in = stream_in;

        // Winner check
        winnerCheckRemote = vCheckR;
        winnerCheckLocal = vCheckL;

    }

    /*
     * Start
     */
    public void run(){

        //start client handler
        try{
            //set trigger for running
            running=true;

            // Set byte buffer for data
            byte[] inputBuffer = new byte[1024];

            //Now the handler is ready to run
            while(running){

                //read incoming bytes into buffer and save the num of bytes as numBytesRead
                int numBytesRead = in.read(inputBuffer);

                // If more than 1 byte, then it must the game request
                // with remote MAC!
                if(numBytesRead > 1){
                    // Set remoter MAC
                    Remote_mac = new String(inputBuffer, 0, numBytesRead);

                    // Set value for new game
                    receivedValue = 9;

                }
                // Otherwise it must be the square number
                // remote user has clicked
                else {
                    // read char and cast it to integer
                    merkki = new String(inputBuffer).charAt(0);
                    receivedValue = (int) merkki;
                }
                // Update UI
                info.post(new Update());

            }


        } catch (Exception exc) {
            try
            {
                clientSocket.close();
            }
            catch (Exception ignore) {}
        }


    }

    /*
     *  Subclass (thread) for communicating with UI
     */

    class Update implements Runnable {
        public void run() {
            Log.d("TAGI", "ClientHandler Update"+ receivedValue);
            // 9 = starting a new game
            if(receivedValue == 9){
                info.setText("Game start");

                // Set remote MAC
                Connection.Remote_MAC = Remote_mac;

                info.invalidate();

            }
            // otherwise its incoming turn
            else {
                // Win trigger. if true, you won
                boolean winTrigger = false;

                switch(receivedValue){
                    case 0:
                        btn = (Button)mActivity.findViewById(R.id.B0);
                        winTrigger = winnerCheckRemote.calculateFields("ULC");
                        break;
                    case 1:
                        btn = (Button)mActivity.findViewById(R.id.B1);
                        winTrigger = winnerCheckRemote.calculateFields("UM");
                        break;
                    case 2:
                        btn = (Button)mActivity.findViewById(R.id.B2);
                        winTrigger = winnerCheckRemote.calculateFields("URC");
                        break;
                    case 3:
                        btn = (Button)mActivity.findViewById(R.id.B3);
                        winTrigger = winnerCheckRemote.calculateFields("MLC");
                        break;
                    case 4:
                        btn = (Button)mActivity.findViewById(R.id.B4);
                        winTrigger = winnerCheckRemote.calculateFields("MM");
                        break;
                    case 5:
                        btn = (Button)mActivity.findViewById(R.id.B5);
                        winTrigger = winnerCheckRemote.calculateFields("MRC");
                        break;
                    case 6:
                        btn = (Button)mActivity.findViewById(R.id.B6);
                        winTrigger = winnerCheckRemote.calculateFields("DLC");
                        break;
                    case 7:
                        btn = (Button)mActivity.findViewById(R.id.B7);
                        winTrigger = winnerCheckRemote.calculateFields("DM");
                        break;
                    case 8:
                        btn = (Button)mActivity.findViewById(R.id.B8);
                        winTrigger = winnerCheckRemote.calculateFields("DRC");
                        break;
                }
                // Set Button text and disable to avoid more clicks
                btn.setText("O");
                btn.setEnabled(false);
                int draw = winnerCheckLocal.isGameADraw() + winnerCheckRemote.isGameADraw();
                // Check if remote player wins
                if(winTrigger == true){
                    info.setText(R.string.you_lose);
                    info.postInvalidate();
                } else if(draw == 9){
                    info.setText(R.string.draw);
                    info.postInvalidate();
                }
            }
        }
    }
}